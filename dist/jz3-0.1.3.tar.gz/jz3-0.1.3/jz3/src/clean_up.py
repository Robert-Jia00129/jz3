# find . -maxdepth 1 -type f
# find . -maxdepth 1 -type f -exec truncate -s 0 {} \;
